teste
<?php /**PATH C:\xampp\htdocs\41b-projetlaravel-claraquintela\claraquintela\resources\views/artist/index.blade.php ENDPATH**/ ?>