<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact</title>
</head>

<body>
    <h1>Call me</h1>

    <form method="post">
        <label> email </label>
        <input type="email">

        <label> message</label>
        <input type="text">

        <input type="submit" name="" id="">

    </form>

</body>

</html>
<?php /**PATH C:\xampp\htdocs\41b-projetlaravel-claraquintela\resto\resources\views/contact.blade.php ENDPATH**/ ?>